
wget http://eecs.berkeley.edu/~rich.zhang/projects/2016_colorization/files/demo_v2/alexnet_release_450000.caffemodel -O ./models/alexnet_release_450000.caffemodel
wget http://eecs.berkeley.edu/~rich.zhang/projects/2016_colorization/files/demo_v2/alexnet_release_450000_nobn.caffemodel -O ./models/alexnet_release_450000_nobn.caffemodel
wget http://eecs.berkeley.edu/~rich.zhang/projects/2016_colorization/files/demo_v2/alexnet_release_450000_nobn_rs.caffemodel -O ./models/alexnet_release_450000_nobn_rs.caffemodel
wget http://eecs.berkeley.edu/~rich.zhang/projects/2016_colorization/files/demo_v2/alexnet_release_450000_nobn_fc_rs.caffemodel -O ./models/alexnet_release_450000_nobn_fc_rs.caffemodel
